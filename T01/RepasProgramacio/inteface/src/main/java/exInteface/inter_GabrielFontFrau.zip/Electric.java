package exInteface;

public interface Electric {
    void carregarBateria();
}
