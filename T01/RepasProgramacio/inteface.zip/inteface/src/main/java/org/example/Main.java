package org.example;

public class Main {
    public static void main(String[] args) {

        Demandant estudiant = new MockStudent();

        System.out.println(estudiant.addStudent());
    }
}