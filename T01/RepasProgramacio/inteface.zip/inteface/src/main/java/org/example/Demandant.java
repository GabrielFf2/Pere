package org.example;

public interface Demandant {

    int addStudent();
    boolean removeStudent();

}
