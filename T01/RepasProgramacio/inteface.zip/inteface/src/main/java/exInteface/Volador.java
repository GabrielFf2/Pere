package exInteface;

public interface Volador {
    void volar();
}
